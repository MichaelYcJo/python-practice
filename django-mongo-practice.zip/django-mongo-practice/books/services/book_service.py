from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
from rest_framework.request import Request

from books.models.book import Book


class BookCreateService:
    def __init__(self, request: Request, data: dict) -> None:
        self.request = request
        self.title = data.get("title")
        self.publication_date = data.get("publication_date")
        self.author = data.get("author")

    def create_book(self):
        book = Book.objects.create(
            title=self.title, publication_date=self.publication_date, author=self.author
        )
        return book
